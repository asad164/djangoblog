from django.shortcuts import render, HttpResponseRedirect
from .models import Articles, Catagory
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.contrib import messages
from django.views.generic import ListView
from django.db.models import Q
import math
from .forms import AddPostForm


# Create your views here.



def home(request):
    catagorries = Catagory.objects.all()
    posts = Articles.objects.all().order_by('-date')
    paginator = Paginator(posts, 3)
    page_number = request.GET.get('page')

    page_obj    = paginator.get_page(page_number)

    return render(request, 'articles/index.html', {'page_obj':page_obj, 'catagorries':catagorries} )



def detailview(request, id):

    post = Articles.objects.get(pk=id)
    return render(request, 'articles/detail.html', {'post':post})


def search(request):
    context = {}
    posts = Articles.objects.all()
    if  request.method == 'GET':
        if request.GET.get("search") != None:
            query = request.GET.get('search')
            queryset = posts.filter(Q(title__icontains=query)|Q(blog_content__icontains=query))

            if len(queryset) < 1:
                messages.info(request, "No Such Data Found")

            page = request.GET.get("page")
            paginator = Paginator(queryset,2)

            try:
                posts = paginator.page(page)
            except PageNotAnInteger:
                posts = paginator.page(1)
            except EmptyPage:
                posts = paginator.page(paginator.num_pages)



            total = queryset.count()

            context.update({
                    'posts':posts,
                   'query':query,
                   'total':total,
                    'page':page


                   })


    return render(request, 'articles/search_results.html', context)


def catagory_post(request, my_id):
    posts = Articles.objects.filter(category = my_id )


    return render(request, 'articles/postcat.html',{'posts':posts} )



def create_blog(request):
    if request.method == 'POST':
        data = {'author':request.user}
        fm = AddPostForm(request.POST, request.FILES,initial=data )
        if fm.is_valid():
            fm.save()
            fm = AddPostForm()
        return HttpResponseRedirect('/account/profile/')

    else:
        data = {'author':request.user}
        fm = AddPostForm(initial=data)
    return render(request,'articles/addpost.html', {'form':fm})


def update_blog(request, id):
    if request.user.is_authenticated:
        if request.method == 'POST':
            data = {'author':request.user}
            pi = Articles.objects.get(pk=id)
            fm = AddPostForm(request.POST, request.FILES, instance=pi)
            if fm.is_valid():
                fm.save()
                messages.success(request, 'Articles Updated')
                return HttpResponseRedirect('/account/profile/')

        else:
            data = {'author':request.user}
            pi = Articles.objects.get(pk=id)
            fm = AddPostForm(instance=pi)
        return render(request, 'articles/addpost.html', {'form':fm})
    else:
        return HttpResponseRedirect('/account/user_login/')