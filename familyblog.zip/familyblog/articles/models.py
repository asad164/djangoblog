from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
from account.models import Account
# Create your models here.



class Catagory(models.Model):
    name = models.CharField(max_length=50, default='অন্যান্য')

    def __str__(self):
        return self.name





class  Articles(models.Model):
    category        = models.ForeignKey(Catagory, on_delete=models.CASCADE)
    title           = models.CharField(max_length=100)
    blog_content    = RichTextUploadingField()
    img             = models.ImageField(upload_to='pics')
    date            = models.DateField(auto_now_add=True)
    author          = models.ForeignKey(Account, on_delete=models.CASCADE)


