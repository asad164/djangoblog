from django.urls import path

from .import views
urlpatterns = [
    path('', views.home, name='home'),
    path('detail/<int:id>/', views.detailview, name='detail'),
    path('add_blog/', views.create_blog, name='addpost'),
    path('updatepost/<int:id>/', views.update_blog, name='updatepost'),
    path('search/', views.search, name='search'),
    path('cat/<int:my_id>/', views.catagory_post, name='post_catagory')
]