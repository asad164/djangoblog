from .models import Articles
from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
from django import forms


class AddPostForm(forms.ModelForm):

    class Meta:
        model = Articles
        fields = '__all__'

        widgets = {
            'title':forms.TextInput(attrs={'class':'form-control'}),
            'blog_content':forms.Textarea(attrs={'class':'form-control'})
        }

        labels = {'title':'Title', 'blog_content':'Write Here', 'img':'Image'}



    def __init__(self, *args, **kwargs):
        super(AddPostForm, self).__init__(*args, **kwargs)
        self.fields['author'].disabled = True


