from django.contrib import admin
from .models import Articles, Catagory
from django.utils.html import format_html
# Register your models here.

@admin.register(Articles)
class ArticlesModelAdmin(admin.ModelAdmin):
    list_display = ['id','content_title','short_blog_content','date', 'author', 'category']
    list_per_page = 3
    save_on_top = True
    search_fields = ['title', 'author']


    def short_blog_content(self, obj):
        return format_html(f'<span>{obj.blog_content[:100]}</span>')


    def content_title(self, obj):
        return format_html(f'<span><a style="color:red" href = "/admin/articles/articles/{obj.id}/change/">{obj.title}</a></span>')



@admin.register(Catagory)
class CatagoryModelAdmin(admin.ModelAdmin):
    list_display = ['id','name']


