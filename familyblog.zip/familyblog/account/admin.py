from django.contrib import admin
from .models import Account
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User


# Register your models here.


@admin.register(Account)
class AccountAdmin(UserAdmin):
    list_display = ['username', 'email', 'age', 'gender', 'image']
    search_fields = ['email', 'username']
    readonly_fields = ['date_joined', 'last_login']


    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()


