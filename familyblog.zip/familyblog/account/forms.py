from django.core import validators
from django import forms
from .models import Account
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField, UserChangeForm
from django.contrib.auth.models import User
from django.utils.translation import gettext, gettext_lazy as _


class SignUpForm(UserCreationForm):
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}), label='Password')
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}), label='Confirm Password')

    class Meta:
        model = Account

        fields = ['email','username','gender', 'age', 'image']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'age': forms.NumberInput(attrs={'class': 'form-control'}),
            'gender': forms.RadioSelect(),
        }





class EditProfileForm(UserChangeForm):
    password = None

    class Meta:
        model = Account
        fields = ['username', 'first_name', 'last_name', 'email', 'age', 'image']
        labels = {'email':'Email'}
