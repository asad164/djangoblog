from django.shortcuts import render
from .forms import SignUpForm, EditProfileForm
from .models import Account
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm, UserChangeForm
from articles.models import Articles

# Create your views here.


def register(request):
    if request.method == 'POST':
        fm = SignUpForm(request.POST, request.FILES)
        if fm.is_valid():
            user = fm.save()
            messages.success(request, 'Registration Successfull')

    elif request.user.is_authenticated:
       return HttpResponseRedirect('/')

    else:
        fm = SignUpForm()
    return render(request, 'account/register.html', {'form':fm})



def user_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request, data=request.POST)
            if fm.is_valid():
                em = fm.cleaned_data['username']
                pw = fm.cleaned_data['password']
                user = authenticate(email=em, password=pw)
                if user is not None:
                    login(request, user)
                    messages.success(request, 'You Have Successfully Logged In')
                    return HttpResponseRedirect('/account/profile/')
        else:
            fm = AuthenticationForm()
        return render(request, 'account/login.html', {'form':fm})
    else:
        return HttpResponseRedirect('/account/profile/')


def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')

def user_profile(request):
    if request.user.is_authenticated:
        if request.method =='POST':
            articles = Articles.objects.filter(author = request.user.id)
            fm = EditProfileForm(request.POST, request.FILES, instance=request.user)
            if fm.is_valid():
                messages.success(request, 'Your Profile Has been Successfully Updated')
                fm.save()
                fm=EditProfileForm()
        else:
            fm = EditProfileForm(instance=request.user)
            articles = Articles.objects.filter(author=request.user.id)

        return render(request, 'account/profile.html', {'user':request.user, 'form':fm, 'articles':articles})
    else:
        return HttpResponseRedirect('/account/user_login/')







def contact(request):
    return render(request, 'account/contact.html')





